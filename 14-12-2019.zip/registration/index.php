<h2>AYOO MAU NGAPAIN...</h2>

<form action="/uploads/download.php" method="post" autocomplete="off">
    <input type="password" name="password">
    <input type="submit">
</form>