<html> 
	<head> 
	   
    <link rel="stylesheet" href="css/slicknav.css"> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.2.61/jspdf.min.js"></script>
    <script src="image.js"></script>  
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="style.css">
	
	</head> 
	
	
	<body> 
	<div class="login"> 
	<form action="download.php" method="post" autocomplete="off">
    <input type="password" name="password">
    <input type="submit" value="Login">	
	</form>
	
	</div>
	
	</body>
	
	
</html>

